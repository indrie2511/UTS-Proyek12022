<?php
include_once "datapasien.php";
include_once "class_BMI_pasien.php";
include_once "class_BMI.php";
?>